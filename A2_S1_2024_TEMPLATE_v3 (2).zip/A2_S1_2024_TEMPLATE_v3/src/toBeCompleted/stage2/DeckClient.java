package toBeCompleted.stage2;

public class DeckClient {
    public static void main(String[] args) {
        Deck deck = new Deck();
        deck.shuffle();
        System.out.println(deck);
    }
}
